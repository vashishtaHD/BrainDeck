from flask import Flask, jsonify, request
import requests, random
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Add this line to enable CORS for your Flask app

@app.route('/api/quizzes', methods=['POST'])
def generate_quiz():
    topic = request.json.get('topic')
    # Make an API request to the free API that provides questions and correct answers
    # Process and retrieve the quiz questions from the API response
    # Return a JSON response with the generated quiz questions
    quiz_questions = generate_quiz_questions(topic)  # Replace with your logic for generating quiz questions
    return jsonify({'questions': quiz_questions})

def generate_quiz_questions(topic):
    # Your logic to generate quiz questions goes here
    # You can use the topic to fetch questions from the free API or generate them programmatically
    # Return the generated quiz questions
    URL = "https://opentdb.com/api.php?amount=10&category=31&difficulty=easy&type=multiple"
    response = requests.post(URL)
    response = response.json()
    qanda = response['results']
    questions = []
    answers = []
    correctanswer = []
    difficulty = []

    for i in range(len(qanda)):
        random_number = random.randint(1, 4)
        questions.append(qanda[i]['question'])
        correctanswer.append(random_number)
        answers.append(qanda[i]['incorrect_answers'])
        answers[i].insert(random_number-1, qanda[i]['correct_answer'])
        difficulty.append(qanda[i]['difficulty']) 
    return questions,answers,correctanswer
    # return questions

if __name__ == '__main__':
    app.run()
