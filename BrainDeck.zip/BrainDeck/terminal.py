import requests, random

URL = "https://opentdb.com/api.php?amount=3&category=31&difficulty=easy&type=multiple"
response = requests.post(URL)
response = response.json()
qanda = response['results']
questions = []
answers = []
correctanswer = []
difficulty = []
score=0

for i in range(len(qanda)):
    random_number = random.randint(1, 4)
    questions.append(qanda[i]['question'])
    correctanswer.append(random_number)
    answers.append(qanda[i]['incorrect_answers'])
    answers[i].insert(random_number-1, qanda[i]['correct_answer'])
    difficulty.append(qanda[i]['difficulty']) 

print("BrainDeck's AI Powered Quiz Generator:")
print("Enter a topic: ")
for i in range(len(qanda)):
    print("Question ",i+1,": ")
    print(questions[i])
    print("Options:")
    for j in range(4):
        print(chr(j+97),")",answers[i][j])
    ans=input()
    if(ans==str(correctanswer[i])):
        score=score+1

print("Quiz Completed")
print("Your Score: ",score)

 